<?php  

	class Fitur_mdl extends CI_Model
	{
		// Read
		public function fiturlist()
		{
			$this->db->select('*');
			$this->db->from('fitur');
			$sql = $this->db->get('');

			return $sql->result();
		}

		// CREATE (STORE)
		public function store()
		{
			$name = $this->input->post('name');
			$fiturtype = $this->input->post('type');
			$facility = $this->input->post('facility');

			$data = array(
				'name' => $name, 
				'fiturtype' => $fiturtype, 
				'facility' => $facility
			);

			$result = $this->db->insert('fitur', $data);
			return $result;
		}

		// get UPDATE item
		public function edit($id)
		{
			$this->db->select('*');
			$this->db->from('fitur');
			$this->db->where('id_fitur', $id);
			$sql = $this->db->get('');

			return $sql->result();
		}

		public function select($id)
		{
			$this->db->select('*');
			$this->db->from('fitur');
			$this->db->where_in('id_fitur', $id);
			$sql = $this->db->get('');

			return $sql->result();
		}
		// UPDATE
		public function update()
		{
			$id = $this->input->post('editid');
			$name = $this->input->post('editname');
			$fiturtype = $this->input->post('edittype');
			$facility = $this->input->post('editfacility');

			$editdata = array(
				'name' => $name, 
				'fiturtype' => $fiturtype, 
				'facility' => $facility
			);
			$this->db->where('id_fitur', $id);
			$this->db->update('fitur', $editdata);
		}

		// DELETE
		public function delete($id)
		{

			$this->db->where('id_fitur', $id);
			$this->db->delete('fitur');
		}

	}
?>