<!-- inner page banner --> 	
<div class="innerpage-banner">
	<div class="layer1">
	</div>
</div>

<!-- welcome -->
<section class="welcome py-5">
	<div class="container py-3">
	<h3 class="heading text-center mb-md-5 mb-4"> Tentang Kami </h3>
		<div class="row welcome-grids">
			<div class="col-lg-6">
			<h4 class="mb-3">Selamat Datang di Hoteling Agency</h4>
			<h3>Ingatlah bahwa kenyamanan adalah kunci untuk menikmati setiap perjalanan.</h3>
			<p class="my-4">Temukan dan pesan hotel terbaik dalam hitungan detik. Kami menyediakan berbagai pilihan hotel yang siap memberikan Anda pengalaman menginap yang autentik dan nyaman. Setiap hotel yang kami tawarkan dirancang untuk membuat Anda merasakan kehangatan dan keindahan budaya lokal selama Anda menginap.</p>
			<p>
					<i class="fa fa-check text-orange mr-2"></i> Certificated International Support.
					<br>
					<i class="fa fa-check text-orange mr-2"></i> Checked Every Place.
					<br>
					<i class="fa fa-check text-orange mr-2"></i> Since 2015.
				</p>
			</div>
			<div class="col-lg-6 mt-lg-0 mt-5 welcome-grid3">
				<div class="position">
					<img src="<?php echo base_url(); ?>assets/frontend/images/banner4.jpg" alt="" class="img-fluid" />
				</div>
			</div>
		</div>
	</div>
</section>
<!-- //welcome -->

<!-- welcome bottom -->
<section class="welcome-bottom">
	<div class="welcome-bottom-layer py-5">
		<div class="container py-lg-5 py-sm-3">
	<h4 class="mb-2">Pengalaman menginap yang sempurna dimulai dari pilihan hotel yang tepat</h4>
<p class="mb-4">Temukan penginapan ideal Anda</p>
<a href="<?= base_url().'index.php/Tour/showall' ?>">Lihat Semua Hotel</a>

		</div>
	</div>
</section>

<!-- welcome -->
<section class="welcome py-5">
	<div class="container py-3">
		<div class="row welcome-grids">
			<div class="col-lg-6 mt-lg-0 mt-5 welcome-grid3">
				<div class="position">
					<img src="<?php echo base_url(); ?>assets/frontend/images/banner2.jpg" alt="" class="img-fluid" />
				</div>
			</div>
			<div class="col-lg-6">
				<h3 class="mt-3">Mengapa Hoteling</h3>
				<p class="my-4">Hoteling adalah platform online yang memungkinkan para pelancong menemukan dan memesan hotel di seluruh dunia. Di sini, para pelancong dapat melihat profil hotel, menghubungi, dan melakukan pemesanan langsung dengan mereka!</p>
				<p>
				Komunitas hotel yang terdaftar di platform kami telah berkembang menjadi sekitar 1.500 hotel, di lebih dari 50 kota dari 68 negara di seluruh dunia! Ini menjadikan kami salah satu komunitas perhotelan terbesar dan terluas di dunia.
				</p>


			</div>
		</div>
	</div>
</section>