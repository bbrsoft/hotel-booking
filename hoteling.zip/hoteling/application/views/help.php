<div class="innerpage-banner">
	<div class="layer1">
	</div>
</div>

<!-- all tour list -->
<section class="tours py-5">
	<div class="container py-3">
	<h3 class="heading text-center mb-md-5 mb-4"> Help </h3>
		<div class="row">
			<div class="col-12 text-center">
				<a href="<?= base_url().'assets/UserManual.pdf' ?>" target="_blank" class="btn-viewall"><i class="fa fa-external-link pr-2"></i>Open User Manual</a>

				<br><br><br>
				<span class="font-weight-bold text-secondary">OR</span>

				<p class="font-italic text-center my-5"> Call to Customer Service Center <br><br> <strong><i class="fa fa-phone pr-2"></i>+628 2169 419 513</strong></p>
			</div>
		</div>
	</div>
</section>