<?php  

	class Booking extends CI_Controller
	{

		public function __construct()
    {
        parent::__construct();
		require_once 'vendor/autoload.php'; 
        // Set konfigurasi Midtrans
        Midtrans\Config::$serverKey = 'SB-Mid-server-tWtQxbYcPyTS3_oVqs85VzVZ';
        Midtrans\Config::$isProduction = false; // Ubah ke true jika di production
        Midtrans\Config::$isSanitized = true;
        Midtrans\Config::$is3ds = true;
    }

		public function index()
		{			
			$data['bookinglist'] = $this->Booking_mdl->tourguidebookinglist();
			$data['innerdata'] = 'tourguide_bookinglist';
			$data['todayrequestlist'] = $this->Request_mdl->todayrequestlist();
			$data['todaybookinglist'] = $this->Booking_mdl->todaybookinglist();
			$data['todayratelist'] = $this->Review_mdl->todayratelist();
			$this->load->view('tourguidetemplate', $data);
		}

		public function add()
		{
			$this->load->helper(array('form', 'url'));
			$this->load->library('form_validation');

			// select 
			$id = $this->uri->segment(3);
			$data['showtour'] = $this->Tour_mdl->show($id);

			// checkdate
			$duration = $data['showtour'][0]->duration;

			$bookdate = $this->uri->segment(4).'-'.$this->uri->segment(5).'-'.$this->uri->segment(6);
			$todate = date('Y-m-d', strtotime($bookdate))." + ".($duration-1)." day";
			$todate = date('Y-m-d', strtotime($todate));
			$datearray = $this->Tour_mdl->getDatesFromRange($bookdate, $todate); 

			$checkbookingdate = $this->Tour_mdl->checkbookingdate($id);

			if (array_intersect($datearray, $checkbookingdate)) {
				echo "<script>alert('Sorry, tourguide is not available in the following day. Please Choose the date again.');</script>";
				redirect(base_url().'index.php/Booking/calendar/'.$id.'/'.$this->uri->segment(4).'/'.$this->uri->segment(5),'refresh');
			} else {
				$data['innerdata'] = 'booking';
				$this->load->view('template', $data);
			}

			

		}


		// calendar 
		public function calendar() 
		{
			$id = $this->uri->segment(3);
			$urlyear = $this->uri->segment(4);
			$urlmonth = $this->uri->segment(5);

			$checkbookingdate = $this->Tour_mdl->checkbookingdate($id);

			$nowyear = date('Y');
			$nowmonth = date('m');
			$nowday = date('d');

			// end day 
				if ($urlmonth == 4 || $urlmonth == 6 || $urlmonth == 9 || $urlmonth == 11) 
					$endday = 31;
				elseif ($urlmonth == 2 && $urlyear % 4 == 0) 
					$endday = 30;
				elseif ($urlmonth == 2)
					$endday = 29;
				else 
					$endday = 32;

			$datedata = array();

			if ($nowyear > $urlyear || (($nowmonth > $urlmonth) && ($nowyear == $urlyear)) || (($urlyear == $nowyear+1) && ($urlmonth > $nowmonth)) || $nowyear+1 < $urlyear) {

				// condition for past date and one year for future

				$datedata = array();

			} elseif ($nowyear < $urlyear || (($nowmonth < $urlmonth) && ($nowyear == $urlyear))) {
				
				// for following date of same year
				for ($i=1; $i < $endday; $i++) { 
					if ($i>0 && $i<10) {
						$editedday = '0'.$i;
					} else {
						$editedday = $i;
					}
					if (in_array($urlyear.'-'.$urlmonth.'-'.$editedday, $checkbookingdate)) {
						continue;
					} else {

						switch ($i) {
							case 1: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'01';
								break;
							case 2: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'02';
								break;
							case 3: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'03';
								break;
							case 4: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'04';
								break;
							case 5: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'05';
								break;
							case 6: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'06';
								break;
							case 7: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'07';
								break;
							case 8: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'08';
								break;
							case 9: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'09';
								break;
							default: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.$i;
								break;
						}
					}
					
				}
			} else {

				// for date of same month and same year

				for ($i=$nowday+3; $i < $endday; $i++) { 
					if ($i>0 && $i<10) {
						$editedday = '0'.$i;
					} else {
						$editedday = $i;
					}

					if (in_array($urlyear.'-'.$urlmonth.'-'.$editedday, $checkbookingdate)) {
						continue;
					} else {
						switch ($i) {
							case 1: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'01';
								break;
							case 2: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'02';
								break;
							case 3: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'03';
								break;
							case 4: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'04';
								break;
							case 5: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'05';
								break;
							case 6: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'06';
								break;
							case 7: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'07';
								break;
							case 8: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'08';
								break;
							case 9: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.'09';
								break;
							default: $datedata[$i] = base_url().'index.php/Booking/add/'.$id.'/'.$urlyear.'/'.$urlmonth.'/'.$i;
								break;
						}
					}

				}
			}

			$this->load->library('calendar');
			$this->calendar->day_type = 'short';
			$this->calendar->show_next_prev = TRUE;
			$this->calendar->next_prev_url = site_url('Booking/calendar/'.$id);

			$data['calendar'] =  $this->calendar->generate($this->uri->segment(4), $this->uri->segment(5), $datedata);

			$data['innerdata'] = 'calendar';
			$this->load->view('template', $data);
		}

		// store 
		public function store()
		{
			$this->form_validation->set_rules('starttime', 'StartTime', 'required', array('required' => 'Please Choose Start Time!'));
			$this->form_validation->set_rules('nooftotalpeople', 'TotalPeople', 'required', array('required' => 'Please Choose Total People!'));
		
			$id = $this->input->post('tourid');
		
			if ($this->form_validation->run() == FALSE) {
				$data['showtour'] = $this->Tour_mdl->show($id);
				$data['innerdata'] = 'booking';
				$this->load->view('template', $data);
			} else {
				$payment_method = $this->input->post('payment_method');
				$totalprice = $this->input->post('tourprice');
				$name = $this->input->post('name');
				$userid = $this->input->post('userid');
				$datalengkapUser = $this->User_mdl->detail($userid); // Perbaiki ID pengguna
				$email = $datalengkapUser[0]->email;
				$phone = $datalengkapUser[0]->phone;
				$trx = '';
		
				if ($payment_method <> 5) {
					// request midtran
					$result = $this->createTransaction($totalprice, $name, $email, $phone, $payment_method);
					if ($result) {
						$trx = $result['transaction_id'];
						$bookingid = $this->Booking_mdl->store($trx);
						echo "<script type='text/javascript'>alert('Transaction Success: " . $result['message'] . "');</script>";
						
					} else {
						log_message('error', 'Transaction Error: ' . $result['message']);
						echo "<script type='text/javascript'>alert('Transaction Error: " . $result['message'] . "');</script>";
						redirect(base_url() . 'index.php/Booking/error', 'refresh');
					}
				} else {
					$bookingid = $this->Booking_mdl->store($trx);
				}
				
				echo "<script type='text/javascript'>alert('Booking Process is Successfully Completed!');</script>";
				redirect(base_url() . 'index.php/Booking/detail/' . $bookingid, 'refresh');
			}
		}

		public function createTransaction($totalprice, $name, $email, $phone, $payment_method)
{
    $bank = 'bni'; // Default bank, adjust based on $payment_method
    if ($payment_method == 1) {
        $bank = 'bni';
    } elseif ($payment_method == 2) {
        $bank = 'mandiri';
    } elseif ($payment_method == 3) {
        $bank = 'bri';
    } elseif ($payment_method == 4) {
        $bank = 'permata';
    }

    $totalprice = floatval($totalprice);
    $gross_amount = round($totalprice);

    $transaction_data = array(
        'payment_type' => 'bank_transfer',
        'bank_transfer' => array(
            'bank' => $bank
        ),
        'transaction_details' => array(
            'order_id' => 'order-' . time(),
            'gross_amount' => $gross_amount,
            'currency' => 'IDR'
        ),
        'item_details' => array(
            array(
                'id' => 'item1',
                'price' => $gross_amount,
                'quantity' => 1,
                'name' => 'Tour Booking'
            )
        ),
        'customer_details' => array(
            'first_name' => $name,
            'email' => $email,
            'phone' => $phone
        )
    );

    $server_key = 'SB-Mid-server-tWtQxbYcPyTS3_oVqs85VzVZ';
    $is_production = False;
    $url = $is_production ? 'https://api.midtrans.com/v2/charge' : 'https://api.sandbox.midtrans.com/v2/charge';

    $ch = curl_init($url);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($transaction_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/json',
        'Authorization: Basic ' . base64_encode($server_key . ':')
    ));

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

	$response_data = json_decode($response, true);
	// log_message('debug', 'Midtrans Success Response: ' . print_r($response_data, true));
	return array(
		'response' => $response_data
	);
   
}


	public function handleSuccess($transaction_id)
{
    // Mengambil detail transaksi
    $server_key = 'SB-Mid-server-tWtQxbYcPyTS3_oVqs85VzVZ';
    $is_production = $this->config->item('midtrans')['is_production'];
    $url = $is_production ? 'https://api.midtrans.com/v2/' . $transaction_id . '/status' : 'https://api.sandbox.midtrans.com/v2/' . $transaction_id . '/status';

    // Inisialisasi cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Basic ' . base64_encode($server_key . ':')
    ));

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code == 200) {
        $response_data = json_decode($response, true);
        // Proses lebih lanjut, seperti mengupdate status transaksi di database
        // dan memberi tahu pengguna
        return array(
            'status' => 'success',
            'message' => 'Transaction is successful',
            'data' => $response_data
        );
    } else {
        return array(
            'status' => 'error',
            'message' => 'Failed to retrieve transaction status'
        );
    }
}

			public function notification()
		{
			$notif = new \Midtrans\Notification();

			$transaction = $notif->transaction_status;
			$type = $notif->payment_type;
			$order_id = $notif->order_id;
			$fraud = $notif->fraud_status;

			if ($transaction == 'capture') {
				if ($type == 'credit_card') {
					if ($fraud == 'challenge') {
						// Update status order jadi challenge
					} else {
						// Update status order jadi success
					}
				}
			} else if ($transaction == 'settlement') {
				// Update status order jadi settlement
			} else if ($transaction == 'pending') {
				// Update status order jadi pending
			} else if ($transaction == 'deny') {
				// Update status order jadi deny
			} else if ($transaction == 'expire') {
				// Update status order jadi expire
			} else if ($transaction == 'cancel') {
				// Update status order jadi cancel
			}
		}

		public function detail()
		{
			$id = $this->uri->segment(3);
			$data['detailbooking'] = $this->Booking_mdl->detail($id);
			$data['innerdata'] = 'booking_detail';
			$this->load->view('template', $data);
		}

		public function show()
		{
			$id = $this->uri->segment(3);
			$data['detailbooking'] = $this->Booking_mdl->detail($id);
			$data['innerdata'] = 'booking_show';
				
			if ($this->session->userdata('role') == 'staff') {
				$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
     			$data['notidata'] = 'adminnoti_tour';
				$this->load->view('stafftemplate', $data);
			} else {
				$data['todayrequestlist'] = $this->Request_mdl->todayrequestlist();
				$data['todaybookinglist'] = $this->Booking_mdl->todaybookinglist();
				$data['todayratelist'] = $this->Review_mdl->todayratelist();
				$this->load->view('tourguidetemplate', $data);
			}
		}

		public function bookinglist()
		{
			$data['requestlist'] = $this->Request_mdl->requestlist($this->session->userdata('id'));
			$data['bookinglist'] = $this->Booking_mdl->bookinglist($this->session->userdata('id'));
			$data['innerdata'] = 'booking_list';
			$this->load->view('template', $data);
		}

		public function cancel()
		{
			$id = $this->uri->segment(3);
			$this->Booking_mdl->cancel($id);
			echo "<script type='text/javascript'>alert('Your Cancellation Request is Successfully Done.');</script>";
			redirect(base_url() . 'index.php/Booking/detail/'.$id, 'refresh');
		}

		public function showall()
		{
			$data['bookinglist'] = $this->Booking_mdl->showall();
			$data['innerdata'] = 'booking_showall';
			$data['tourtypelist'] = $this->Tourtype_mdl->tourtypelist();
			$data['regionlist'] = $this->Region_mdl->regionlist();
     		$data['todaytourlist'] = $this->Tour_mdl->todaytourlist();
			$data['notidata'] = 'adminnoti_tour';
			$this->load->view('stafftemplate', $data);
		}
	}
?>